import{b as o}from"./chunk-IVXGQ4SS.js";var r=o("GoogleAuth",{web:()=>import("./chunk-QAJOPFJV.js").then(e=>new e.GoogleAuthWeb)});export{r as a};
